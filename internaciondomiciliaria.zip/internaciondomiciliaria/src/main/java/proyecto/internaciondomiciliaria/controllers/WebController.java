package proyecto.internaciondomiciliaria.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import proyecto.internaciondomiciliaria.entities.Chofer;
import proyecto.internaciondomiciliaria.entities.Equipo;
import proyecto.internaciondomiciliaria.entities.Paciente;
import proyecto.internaciondomiciliaria.entities.Visita;

import proyecto.internaciondomiciliaria.repositories.ChoferRepository;
import proyecto.internaciondomiciliaria.repositories.EquipoRepository;
import proyecto.internaciondomiciliaria.repositories.PacienteRepository;
import proyecto.internaciondomiciliaria.repositories.VisitaRepository;

@Controller
public class WebController {

    private PacienteRepository pacienteRepository = new PacienteRepository();
    private EquipoRepository equipoRepository = new EquipoRepository();
    private ChoferRepository choferRepository = new ChoferRepository();
    private VisitaRepository visitaRepository = new VisitaRepository();

    private String mensajePaciente = "Ingrese un nuevo Paciente!";
    private String mensajeEquipo = "Ingrese un nuevo Equipo!";
    private String mensajeChofer = "Ingrese un nuevo Chofer!";
    private String mensajeVisita = "Ingrese una nueva Visita!";

    @GetMapping("/")
    public String getIndex() {
        return "index";
    }

    @GetMapping("/pacientes")
    public String getPacientes(
            @RequestParam(name = "buscarNombre", required = false, defaultValue = "") String buscarNombre,
            Model model) {
        model.addAttribute("mensajePaciente", mensajePaciente);
        model.addAttribute("paciente", new Paciente());
        // model.addAttribute("cursos", cursoRepository.getAll());
        model.addAttribute("LikePacienteNombre", pacienteRepository.getLikePacienteNombre(buscarNombre));// MODIFICAR
        return "pacientes";
    }
    

    @GetMapping("/equipos")
    public String getEquipos(
            @RequestParam(name = "buscarEquipo", required = false, defaultValue = "") String buscarEquipo,
            Model model) {
        model.addAttribute("mensajeEquipo", mensajeEquipo);
        model.addAttribute("equipo", new Equipo());
        model.addAttribute("LikeEquipoDescripcion", equipoRepository.getLikeEquipoDescripcion(buscarEquipo));
        model.addAttribute("equipos", equipoRepository.getAll());
        return "equipos";
    }

    @GetMapping("/visitas")
    public String getVisitas(
            @RequestParam(name = "buscarVisita", required = false, defaultValue = "") String buscarVisita,
            Model model) {
        model.addAttribute("mensajeVisita", mensajeVisita);
        model.addAttribute("visita", new Visita());
        // model.addAttribute("cursos", cursoRepository.getAll());
        model.addAttribute("ByVisitaFecha", visitaRepository.getByVisitaFecha(buscarVisita));
        return "visitas";
    }

    @GetMapping("/choferes")
    public String getChoferes(
            @RequestParam(name = "buscarChofer", required = false, defaultValue = "") String buscarChofer,
            Model model) {
        model.addAttribute("mensajeChofer", mensajeChofer);
        model.addAttribute("chofer", new Chofer());
        // model.addAttribute("cursos", cursoRepository.getAll());
        model.addAttribute("LikeChoferNombre", choferRepository.getLikeChoferNombre(buscarChofer));
        return "choferes";
    }

    @PostMapping("/savePaciente")
    public String save(@ModelAttribute Paciente paciente) {
        try {
            pacienteRepository.save(paciente);
            mensajePaciente = "Se guardo el paciente id: " + paciente.getId_paciente();
        } catch (Exception e) {
            mensajePaciente = "Ocurrio un error";
        }
        return "redirect:pacientes";
    }

    @PostMapping("/saveEquipo")
    public String save(@ModelAttribute Equipo equipo) {
        try {
            equipoRepository.save(equipo);
            mensajeEquipo = "Nuevo equipo registrado con el id: " + equipo.getId_equipo();
        } catch (Exception e) {
            mensajeEquipo = "Ocurrio un error";
        }
        return "redirect:equipos";
    }

    @PostMapping("/saveVisita")
    public String save(@ModelAttribute Visita visita) {
        try {
            visitaRepository.save(visita);
            mensajeVisita = "Visita registrada con el id: " + visita.getId_visita();
        } catch (Exception e) {
            mensajeVisita = "Ocurrio un error";
        }
        return "redirect:visita";
    }

    @PostMapping("/saveChofer")
    public String save(@ModelAttribute Chofer chofer) {
        try {
            choferRepository.save(chofer);
            mensajeChofer = "Nuevo chofer con el id: " + chofer.getId_chofer();
        } catch (Exception e) {
            mensajeChofer = "Ocurrio un error";
        }
        return "redirect:pacientes";
    }

}
