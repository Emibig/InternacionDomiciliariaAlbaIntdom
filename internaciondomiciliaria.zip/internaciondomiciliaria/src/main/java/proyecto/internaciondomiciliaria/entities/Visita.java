package proyecto.internaciondomiciliaria.entities;

import proyecto.internaciondomiciliaria.enums.Horario;

public class Visita {
    private int id_visita;
    private int id_chofer;
    private String nombre_chofer;
    private int id_paciente;
    private String zona;
    private String fecha;
    private Horario hora_inicio;
    private Horario hora_fin;
    private String coordinado;
    private String concretado;

    public Visita() {
    }
    // sin ids ni chofer

    public Visita(String zona, String fecha, Horario hora_inicio, Horario hora_fin, String coordinado,
            String concretado) {
        this.zona = zona;
        this.fecha = fecha;
        this.hora_inicio = hora_inicio;
        this.hora_fin = hora_fin;
        this.coordinado = coordinado;
        this.concretado = concretado;
    }

    // sin id visita ni asignacion paciente
    public Visita(int id_chofer, String nombre_chofer, String zona, String fecha, Horario hora_inicio, Horario hora_fin,
            String coordinado, String concretado) {
        this.id_chofer = id_chofer;
        this.nombre_chofer = nombre_chofer;
        this.zona = zona;
        this.fecha = fecha;
        this.hora_inicio = hora_inicio;
        this.hora_fin = hora_fin;
        this.coordinado = coordinado;
        this.concretado = concretado;
    }

    // con id chofer, nombre ch y pcte
    public Visita(int id_chofer, String nombre_chofer, int id_paciente, String zona, String fecha, Horario hora_inicio,
            Horario hora_fin, String coordinado, String concretado) {
        this.id_chofer = id_chofer;
        this.nombre_chofer = nombre_chofer;
        this.id_paciente = id_paciente;
        this.zona = zona;
        this.fecha = fecha;
        this.hora_inicio = hora_inicio;
        this.hora_fin = hora_fin;
        this.coordinado = coordinado;
        this.concretado = concretado;
    }

    // parametrico total
    public Visita(int id_visita, int id_chofer, String nombre_chofer, int id_paciente, String zona, String fecha,
            Horario hora_inicio, Horario hora_fin, String coordinado, String concretado) {
        this.id_visita = id_visita;
        this.id_chofer = id_chofer;
        this.nombre_chofer = nombre_chofer;
        this.id_paciente = id_paciente;
        this.zona = zona;
        this.fecha = fecha;
        this.hora_inicio = hora_inicio;
        this.hora_fin = hora_fin;
        this.coordinado = coordinado;
        this.concretado = concretado;

    }

    @Override
    public String toString() {
        return "Visita [id_visita=" + id_visita + ", id_chofer=" + id_chofer + ", nombre_chofer=" + nombre_chofer
                + ", id_paciente=" + id_paciente + ", zona=" + zona + ", fecha=" + fecha + ", hora_inicio="
                + hora_inicio + ", hora_fin=" + hora_fin + ", coordinado=" + coordinado + ", concretado=" + concretado
                + "]";
    }

    public int getId_visita() {
        return id_visita;
    }

    public void setId_visita(int id_visita) {
        this.id_visita = id_visita;
    }

    public int getId_chofer() {
        return id_chofer;
    }

    public void setId_chofer(int id_chofer) {
        this.id_chofer = id_chofer;
    }

    public String getNombre_chofer() {
        return nombre_chofer;
    }

    public void setNombre_chofer(String nombre_chofer) {
        this.nombre_chofer = nombre_chofer;
    }

    public int getId_paciente() {
        return id_paciente;
    }

    public void setId_paciente(int id_paciente) {
        this.id_paciente = id_paciente;
    }

    public String getZona() {
        return zona;
    }

    public void setZona(String zona) {
        this.zona = zona;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public Horario getHora_inicio() {
        return hora_inicio;
    }

    public void setHora_inicio(Horario hora_inicio) {
        this.hora_inicio = hora_inicio;
    }

    public Horario getHora_fin() {
        return hora_fin;
    }

    public void setHora_fin(Horario hora_fin) {
        this.hora_fin = hora_fin;
    }

    public String getCoordinado() {
        return coordinado;
    }

    public void setCoordinado(String coordinado) {
        this.coordinado = coordinado;
    }

    public String getConcretado() {
        return concretado;
    }

    public void setConcretado(String concretado) {
        this.concretado = concretado;
    }

}
