package proyecto.internaciondomiciliaria.enums;

public enum Horario {_9hs,_10hs,_11hs,_12hs,_13hs,_14hs,_15hs,_16hs,_17hs,_18hs,}