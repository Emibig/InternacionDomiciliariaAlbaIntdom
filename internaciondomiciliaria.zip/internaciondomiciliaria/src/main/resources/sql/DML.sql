-- Insertar datos en la tabla "pacientes"
INSERT INTO pacientes (nombre, nro_socio, cliente, celular, calle_altura, entrecalles, piso_departamento, localidad,zona)
VALUES
    ('Abad Jose', '3645223', 'Swiss Medical S.A.', 1511111, 'A Lamas 2263', NULL, '', 'CABA','dos'),
    ('Bastista Salomon', '62360030', 'MEDICUS', 1522222,'J B Alberdi 3047 4A', '', '', 'CABA','tres'),
    ('Centenario Mariana', '7777473', 'Hospital Alemán',1533333, 'zapiola 600', '', '', 'MERLO','oeste'),
    ('Dieguez Martha Edith', '625725603', 'Hospital Alemán',1544444, 'juncal 2676', '', '', 'CABA','dos'),
    ('Guerrero Liliana', '70352723', 'Swiss Medical S.A.',1555555,'Gurruchaga 440', 'Corrientes y Camargo', '4ºD', 'CABA','dos'),
    ('Figueroa Eduardo Pablo', '7277563', 'Swiss Medical S.A.', 156666666,'Eizaguirre 3774', '(e/Ombu y Zapiola)','', 'SAN JUSTO', 'oeste'),
    ('Huergo Vicenta', '1238', 'AIRMED S.R.L.',15666666, 'De los Reseros 700 - Residencia', '', '', 'PARQUE LELOIR','oeste'),
    ('Ibañez Sebastian', '05266453', 'Swiss Medical',1577777, 'J M Campos 2276 ', '','PB B Ed 22', 'SAN ANDRES', 'norte'),
	('Juarez Grandi', '1245', 'BC&B', 1010101, 'Plaza 2000', '', '', 'CABA','uno'),
    ('Lauria Susana Alicia', '3537002', 'Swiss Medical', 151111111, 'Aviador Saint Wxupery 2460', 'fredes y breiriot', '', 'EL PALOMAR','oeste'),
    ('Mendoza Elvira Elina', '637045002', 'OSDE',1512121212, 'Jose Fusch 3737', '', '', 'MORÓN','oeste'),
    ('Niev Amparo', '3740700', 'OMINT S.A.', 151111189,'Luis de Sarro 342', '', '', 'MONTE GRANDE','sur'),
    ('Perez Eduardo', '5678', 'AIRMED S.R.L.',15115151,  'Estanislao Zeballos 720', 'E Alvarez y Cervino','', 'MORENO', 'oeste'),
    ('Zabatino David Guillermo', '60077073', 'Swiss Medical ', 1512367, 'Panama 724', '7° A', '', 'CABA','dos');
    select* from pacientes;


INSERT INTO equipos ( id_equipo, descripcion, codigo_interno, cantidad)
VALUES
    ( 1, 'Cama ortopedica con colchon hospitalario y juego de barandas', 0101, 1),
    ( 2, 'Colchon de aire', 0201, 1),
    ( 3, 'Bomba de infusión enteral', 1100, 1),
    ( 4, 'Silla de ruedas', 0300, 1),
    ( 5, 'Elevador de inodoro aluminio', 0405, 1),
	( 6, 'Cama ortopedica electrica con colchon hospitalario y barandas', 0102, 1),
    ( 7, 'Colchon de aire peso especial', 0202, 1),
    ( 8, 'Pie de suero', 0109, 1),
    ( 9, 'Silla de ruedas peso especial', 0306, 1),
    (10, 'Andador con ruedas', 0502, 1);

-- Insertar las asignaciones de los pacientes a los equipos
INSERT INTO asignaciones_pacientes (id_paciente, id_equipo)
VALUES
	(1, 1),
	(2, 2),
	(3, 3),
	(4, 4), 
	(5, 5), 
	(6, 6),
	(7, 7),
    (8, 8), 
	(9, 9), 
	(10, 10),
	(11, 4),
	(12, 2),
    (13, 2),
    (14, 4);

    INSERT INTO choferes(zona,vehiculo,nombre_chofer)VALUES
		('norte','Fiorino','Renzo'),
		('uno','Fiorino','Gabriel'),
		('sur','Ducato','Gustavo'),
		('tres','Ducato','Maxi'),
		('oeste','Fiorino','Hugo'),
		('dos','Fiorino','Jo');

    INSERT INTO visitas (fecha, hora_inicio, hora_fin, coordinado, concretado, zona)
VALUES
	('22-05-2023', '_9hs', '_17hs', 'OK', 'estado a confirmar', 'uno'),
	('22-05-2023', '_9hs', '_17hs', 'OK', 'pendiente,se fue', 'norte'),
    ('23-05-2023', '_9hs', '_17hs', 'OK', 'estado a confirmar', 'dos'),
    ('23-05-2023', '_9hs', '_17hs', 'OK', 'estado a confirmar', 'sur'),
    ('24-05-2023', '_9hs', '_17hs', 'OK', 'estado a confirmar', 'tres'),
	('24-05-2023', '_9hs', '_17hs', 'OK', 'pendiente,fallecio', 'oeste');
    
    -- completo el chofer en la tabla visitas segun la zona de la tabla chofer 
UPDATE visitas v
INNER JOIN choferes c 
ON c.zona = v.zona
SET v.id_chofer = c.id_chofer, v.nombre_chofer = c.nombre_chofer
WHERE v.id_chofer IS NULL;

-- completo los pacientes en tabla equipos 
UPDATE equipos e
JOIN asignaciones_pacientes a ON a.id_equipo = e.id_equipo
SET e.id_paciente = a.id_paciente;

-- asignar pacientes a las visitas
UPDATE visitas v
JOIN pacientes p ON v.zona = p.zona
SET v.id_paciente = p.id_paciente;

UPDATE choferes c
JOIN visitas v ON c.zona = v.zona 
SET c.id_visita = v.id_visita;


   
   
    
        
    
